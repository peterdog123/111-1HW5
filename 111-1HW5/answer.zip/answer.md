﻿# 第5次作業-作業-HW5
>
>學號：109111119 
><br />
>姓名：唐睿翔 
><br />
>作業撰寫時間：30 (mins，包含程式撰寫時間)
><br />
>最後撰寫文件日期：2022/12/15
>

本份文件包含以下主題：(至少需下面兩項，若是有多者可以自行新增)
- [x]說明內容
- [x]個人認為完成作業須具備觀念

## 說明程式與內容


```csharp
protected void Page_Load(object sender, EventArgs e)
        {
            string s_str = ConfigurationManager.ConnectionStrings["MSSQLLocalDB"].ConnectionString;
            if(!IsPostBack)
            try
            {
                SqlConnection o_str = new SqlConnection(s_str);
                o_str.Open();
                SqlDataAdapter o_A = new SqlDataAdapter("SELECT * from Users", o_str);
                DataSet o_Set = new DataSet();
                o_A.Fill(o_Set, "zz");
                gd_View.DataSource = o_Set;
                gd_View.DataBind();
                o_str.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex.ToString());
            }
        }

        protected void btn_Insert_Click(object sender, EventArgs e)
        {
            string s_str = ConfigurationManager.ConnectionStrings["MSSQLLocalDB"].ConnectionString;
            try
            {
                SqlConnection o_str = new SqlConnection(s_str);
                SqlDataAdapter o_A = new SqlDataAdapter("SELECT * from Users", o_str);
                o_str.Open();
                SqlCommand o_cmd = new SqlCommand("Insert into Users (Id, Name, Birthday) "+"value(@Name, @DataTime)",o_str);
                o_cmd.Parameters.Add("@Name", SqlDbType.NVarChar, 50);
                o_cmd.Parameters["@Name"].Value = "阿貓阿狗";
                o_cmd.Parameters.Add("@DataTime", SqlDbType.DateTime);
                o_cmd.Parameters["@DataTime"].Value = "2000/10/10";
                o_cmd.ExecuteNonQuery();
                Response.Redirect("https://localhost:44393/WebForm1.aspx",false);
                HttpContext.Current.ApplicationInstance.CompleteRequest();
                o_str.Close();
            }
            catch(Exception o_e)
            {
                Response.Write(o_e.ToString());
            }
        }
```


```html
<body>
    <form id="form1" runat="server">
        <div>
            <asp:Button ID="btn_Insert" runat="server" Text="點我新增資料夾" OnClick="btn_Insert_Click" />
            <asp:GridView ID="gd_View" runat="server"></asp:GridView>
        </div>
    </form>
</body>
```


## 個人認為完成作業須具備觀念

了解建立資料庫，如何運用SQL Injection設定資料表裡面的資料，再用網頁與資料庫座結合呈現資料表。
